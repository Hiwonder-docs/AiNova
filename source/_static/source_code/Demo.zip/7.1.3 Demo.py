import Hiwonder

print("Hello")