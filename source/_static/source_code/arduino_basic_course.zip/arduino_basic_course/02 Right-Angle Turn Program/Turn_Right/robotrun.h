/**************************************************************
 * company：深圳市幻尔科技有限公司
 * file：WonderCam.h
 * date&&author：20231218 && CuZn
 * brief：AINova onboard ESP32 and STM32 communication module（AINova板载 ESP32 与 STM32 通讯模块）
**************************************************************/
#ifndef ROBOTRUN_H_
#define ROBOTRUN_H_

#include <Arduino.h>
#include <Wire.h>
#include <HardwareSerial.h>

#define ets_serial Serial2

class robotrun
{
  public:
    void begin(void);

    void set_motor_speed(int m1, int m2);
    void hw_encoder_motor_set_motor_type(uint8_t motortype);
    int hw_encoder_motor_set_speed_base(float new_speed1, float new_speed2);
};


#endif //ROBOTRUN_H_
