import Hiwonder
import time
from Hiwonder import Buzzer

# initialize variables
cam = Hiwonder.WonderCam(Hiwonder.Port(4))  # Initialize the IIC interface of the WonderCam vision module (初始化小幻熊视觉模块的IIC接口)
i2csonar_4 = Hiwonder.I2CSonar(Hiwonder.Port(4))  # Initialize the IIC interface of the RGB ultrasonic sensor (初始化发光超声波的IIC接口)
en_motor = Hiwonder.EncoderMotor
_LEN_ON = 0
_TRACK_X = 0
_TRACK_Y = 0
_SPEED = 0
_DIREC = 0


i2csonar_4.setRGB(0,0x00,0x00,0x00)  # Turn off the RGB light of the ultrasonic sensor (关闭发光超声波的RGB灯)
en_motor.setType(en_motor.TT_MOTOR)  # Initialize the encoder motor model as TT motor (初始化编码电机的型号为TT马达)
en_motor.stop(en_motor.AllMotor)  # Stop the encoder motor operation (停止编码电机的运行)
cam.switchFunc(cam.ColorDetect)  # Set the WonderCam vision module to color recognition mode (设置小幻熊视觉模块的工作模式为颜色识别模式)
Buzzer.playTone(698,125,False)
_LEN_ON = -1


def on_button_A_clicked():  # Fill light control function (补光灯控制函数)
  global cam
  global i2csonar_4
  global en_motor
  global _LEN_ON
  global _TRACK_X
  global _TRACK_Y
  global _SPEED
  global _DIREC

  _LEN_ON = (0-_LEN_ON)
  if (_LEN_ON>0):
    cam.setLed(cam.LED_ON)  # Turn on the fill light of the WonderCam vision module (打开小幻熊视觉模块的补光灯)
  else:
    cam.setLed(cam.LED_OFF)


def start_main():
  global cam
  global i2csonar_4
  global en_motor
  global _LEN_ON
  global _TRACK_X
  global _TRACK_Y
  global _SPEED
  global _DIREC

  while True:
    cam.updateResult()  # Update and get data from the vision module (更新并获取视觉模块的数据)
    if cam.isColorOfIdDetected(1):  # Determine whether the learned color No.1 is recognized (判断是否识别到已学习的1号颜色)
      _TRACK_X = cam.getColorOfId(1)[0]  # Get the center X coordinate of color No.1 (获取1号颜色的中心X坐标)
      _TRACK_Y = cam.getColorOfId(1)[1]  # Get the center Y coordinate of color No.1 (获取1号颜色的中心Y坐标)
      if (_TRACK_Y<120):  # If Y is less than 120, the color center is in the upper half; calculate motor speed and move forward (如果Y小于120，表明颜色的中心点在上半部分，计算小车的电机速度，控制小车前进)
        _SPEED = (((120-_TRACK_Y))*0.7)
      else:  #  If Y is greater than 120, the color center is in the lower half; calculate motor speed and move backward (如果Y大于120，颜色中心点在下半部分，计算小车的电机速度，控制小车后退)
        _SPEED = (((120-_TRACK_Y))*0.5)
      _DIREC = (((160-_TRACK_X))*0.25)  # Determine whether to turn based on the X coordinate of the center (根据中心X的坐标，计算小车是否进行转向) 
      en_motor.setSpeed(en_motor.Motor1,(_SPEED-_DIREC))  # Control the car movement proportionally (根据比例控制小车进行移动) 
      en_motor.setSpeed(en_motor.Motor2,(_SPEED+_DIREC))
    else:  # Stop motor operation if the color is not recognized (未识别到就停止电机运行)
      en_motor.stop(en_motor.AllMotor)
    time.sleep(0.05)

Hiwonder.Button_A.Clicked(on_button_A_clicked) # Register button A detection task and set the callback function (注册按键A检测任务，并设置回调函数)
Hiwonder.startMain(start_main)
