from Hiwonder import Buzzer
import Hiwonder
import time

# initialize variables
cam = Hiwonder.WonderCam(Hiwonder.Port(4))  # Initialize the IIC interface of the WonderCam vision module (初始化小幻熊视觉模块的IIC接口) 
i2csonar_4 = Hiwonder.I2CSonar(Hiwonder.Port(4))  # Initialize the IIC interface of the RGB ultrasonic sensor (初始化发光超声波的IIC接口)
_LED_ON = 0
num = 0


i2csonar_3.setRGB(0,0x00,0x00,0x00)  # Turn off the RGB light of the ultrasonic sensor (关闭发光超声波的RGB灯)
cam.switchFunc(cam.NumberRecognition)  # Set the WonderCam vision module to digital recognition mode （设置小幻熊视觉模块的工作模式为数字识别模式）
Buzzer.playTone(698,125,False)
_LED_ON = -1
Hiwonder.Neopixel_onboard.fill(0xff,0xcc,0xcc)  # Set the onboard RGB light color to pink （设置板载RGB灯的颜色为粉色）
Buzzer.setVolume(5)  # Set the buzzer volume to 5 （设置蜂鸣器的音量为5）

def on_button_A_clicked():  # Fill light control function （补光灯控制函数）
  global cam
  global i2csonar_3
  global _LED_ON
  global num

  _LED_ON = (0-_LED_ON)
  if (_LED_ON>0):
    cam.setLed(cam.LED_ON)  # Turn on the WonderCam vision module's fill light （打开小幻熊视觉模块的补光灯）
  else:
    cam.setLed(cam.LED_OFF)


def xiao_mao_lv():  # Play "Little Donkey" music (blocking mode, wait until music finishes) （播放小毛驴音乐（播放模式为阻塞式，需要等待音乐播放完毕））
  global cam
  global i2csonar_3
  global _LED_ON
  global num

  Buzzer.playTone(523,500,True)
  Buzzer.playTone(523,500,True)
  Buzzer.playTone(523,500,True)
  Buzzer.playTone(659,500,True)
  Buzzer.playTone(784,500,True)
  Buzzer.playTone(784,500,True)
  Buzzer.playTone(784,500,True)
  Buzzer.playTone(784,500,True)
  Buzzer.playTone(880,500,True)
  Buzzer.playTone(880,500,True)
  Buzzer.playTone(880,500,True)
  Buzzer.playTone(1047,500,True)
  Buzzer.playTone(784,1000,True)
  Buzzer.playTone(698,500,True)
  Buzzer.playTone(698,500,True)
  Buzzer.playTone(698,500,True)
  Buzzer.playTone(880,500,True)
  Buzzer.playTone(659,500,True)
  Buzzer.playTone(659,500,True)
  Buzzer.playTone(659,500,True)
  Buzzer.playTone(659,500,True)
  Buzzer.playTone(587,500,True)
  Buzzer.playTone(587,500,True)
  Buzzer.playTone(587,500,True)
  Buzzer.playTone(587,500,True)
  Buzzer.playTone(784,750,True)
  Buzzer.playTone(523,500,True)
  Buzzer.playTone(523,500,True)
  Buzzer.playTone(523,500,True)
  Buzzer.playTone(659,500,True)
  Buzzer.playTone(784,500,True)
  Buzzer.playTone(784,500,True)
  Buzzer.playTone(784,500,True)
  Buzzer.playTone(784,500,True)
  Buzzer.playTone(880,500,True)
  Buzzer.playTone(880,500,True)
  Buzzer.playTone(880,500,True)
  Buzzer.playTone(1047,500,True)
  Buzzer.playTone(784,1000,True)
  Buzzer.playTone(698,500,True)
  Buzzer.playTone(698,500,True)
  Buzzer.playTone(698,500,True)
  Buzzer.playTone(880,500,True)
  Buzzer.playTone(659,250,True)
  Buzzer.playTone(659,250,True)
  Buzzer.playTone(659,250,True)
  Buzzer.playTone(659,250,True)
  Buzzer.playTone(659,500,True)
  Buzzer.playTone(659,500,True)
  Buzzer.playTone(587,500,True)
  Buzzer.playTone(587,500,True)
  Buzzer.playTone(587,500,True)
  Buzzer.playTone(659,500,True)
  Buzzer.playTone(523,1000,True)


def liang_zhi_lao_hu():  # Play "Two Tigers" music (blocking mode, wait until music finishes) （播放两只老虎音乐（播放模式为阻塞式，需要等待音乐播放完毕））
  global cam
  global i2csonar_3
  global _LED_ON
  global num

  for count in range(2):
    Buzzer.playTone(523,500,True)
    Buzzer.playTone(587,500,True)
    Buzzer.playTone(659,500,True)
    Buzzer.playTone(523,500,True)
  for count in range(2):
    Buzzer.playTone(659,500,True)
    Buzzer.playTone(698,500,True)
    Buzzer.playTone(784,1000,True)
  for count in range(2):
    Buzzer.playTone(784,250,True)
    Buzzer.playTone(880,250,True)
    Buzzer.playTone(784,250,True)
    Buzzer.playTone(698,250,True)
    Buzzer.playTone(659,500,True)
    Buzzer.playTone(523,500,True)
  for count in range(2):
    Buzzer.playTone(523,500,True)
    Buzzer.playTone(392,500,True)
    Buzzer.playTone(523,1000,True)

def xiao_xing_xing():  # Play "Twinkle Twinkle Little Star" music (blocking mode, wait until music finishes) （播放星星音乐（播放模式为阻塞式，需要等待音乐播放完毕））
  global cam
  global i2csonar_3
  global _LED_ON
  global num

  xiao_xing_xing_bu_fen_()  
  for count in range(2):
    Buzzer.playTone(784,500,True)
    Buzzer.playTone(784,500,True)
    Buzzer.playTone(698,500,True)
    Buzzer.playTone(698,500,True)
    Buzzer.playTone(659,500,True)
    Buzzer.playTone(659,500,True)
    Buzzer.playTone(587,1000,True)
  xiao_xing_xing_bu_fen_()

def xiao_xing_xing_bu_fen_():
  global cam
  global i2csonar_3
  global _LED_ON
  global num

  Buzzer.playTone(523,500,True)
  Buzzer.playTone(523,500,True)
  Buzzer.playTone(784,500,True)
  Buzzer.playTone(784,500,True)
  Buzzer.playTone(880,500,True)
  Buzzer.playTone(880,500,True)
  Buzzer.playTone(784,1000,True)
  Buzzer.playTone(698,500,True)
  Buzzer.playTone(698,500,True)
  Buzzer.playTone(659,500,True)
  Buzzer.playTone(659,500,True)
  Buzzer.playTone(587,500,True)
  Buzzer.playTone(587,500,True)
  Buzzer.playTone(523,1000,True)

def start_main():
  global cam
  global i2csonar_3
  global _LED_ON
  global num

  while True:
    cam.updateResult()  # Update and get data from the vision module （更新并获取视觉模块的数据）
    num = cam.getNumMaxProbOfId()  # Get the digital recognition result （获取数字识别结果）
    if (num>0):  # If the recognized number is greater than 0 （如果识别到的数字大于0）
      if (num==1):  # If number 1 is recognized, set RGB light to red （识别到数字1，设置RGB灯为红色）
        Hiwonder.Neopixel_onboard.fill(0xff,0x00,0x00)
      else:
        if (num==2):  # If number 2 is recognized, set RGB light to purple （识别到数字2，设置RGB灯为紫色）
          Hiwonder.Neopixel_onboard.fill(0xcc,0x33,0xcc)
        else:
          if (num==3):  # If number 3 is recognized, set RGB light to green and play "Two Tigers" music （识别到数字3，设置RGB灯为绿灯，并播放两只老虎音乐） 
            Hiwonder.Neopixel_onboard.fill(0x33,0xff,0x33)
            liang_zhi_lao_hu()
          else:
            if (num==4):  # If number 4 is recognized, set RGB light to blue and play "Twinkle Twinkle Little Star" music （识别到数字4，设置RGB灯为蓝灯，并播放小星星音乐）
              Hiwonder.Neopixel_onboard.fill(0x33,0x66,0xff)
              xiao_xing_xing()
            else:
              if (num==5):  # If number 5 is recognized, set RGB light to light blue and play "Little Donkey" music （识别到数字5，设置RGB灯为浅蓝灯，并播放小毛驴音乐）
                Hiwonder.Neopixel_onboard.fill(0x99,0x99,0xff)
                xiao_mao_lv()
              else:
                Hiwonder.Neopixel_onboard.fill(0xff,0xff,0x00)  # If no number between 1-5 is recognized, set RGB light to yellow （如果未识别到数字1-5，那么就设置RGB灯为黄色）
    else:  # If no number is recognized, turn off RGB light （未识别到数字时，关闭RGB灯）
      Hiwonder.Neopixel_onboard.clear()
      time.sleep(0.01)

Hiwonder.Button_A.Clicked(on_button_A_clicked)  # Register button A detection task and set callback function （注册按键A检测任务，并设置回调函数）
Hiwonder.startMain(start_main)

