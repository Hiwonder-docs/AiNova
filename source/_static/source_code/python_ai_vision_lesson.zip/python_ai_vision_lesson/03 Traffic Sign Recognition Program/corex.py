import Hiwonder
import time
from Hiwonder import Buzzer

# initialize variables
cam = Hiwonder.WonderCam(Hiwonder.Port(4))  # Initialize the IIC interface of the WonderCam vision module (初始化小幻熊视觉模块的IIC接口) 
i2csonar_4 = Hiwonder.I2CSonar(Hiwonder.Port(4))  # Initialize the IIC interface of the RGB ultrasonic sensor (初始化发光超声波的IIC接口)
en_motor = Hiwonder.EncoderMotor
_LEN_ON = 0
_LAST_CLASS_ID = 0
_CLASS_COUNT = 0


i2csonar_4.setRGB(0,0x00,0x00,0x00)  # Turn off the RGB light of the ultrasonic sensor (关闭发光超声波的RGB灯) 
en_motor.setType(en_motor.TT_MOTOR)  # Initialize the encoder motor model as TT motor (初始化编码电机的型号为TT马达)
en_motor.stop(en_motor.AllMotor)  # Stop the encoder motor operation (停止编码电机的运行) 
cam.switchFunc(cam.LandmarkRecognition)  # Set the WonderCam vision module to traffic sign recognition mode (设置小幻熊视觉模块的工作模式为路标识别模式)
Buzzer.playTone(698,125,False)
_LEN_ON = -1




def on_button_A_clicked():  # Fill light control function (补光灯控制函数)
  global cam
  global i2csonar_4
  global en_motor
  global _LEN_ON
  global _LAST_CLASS_ID
  global _CLASS_COUNT

  _LEN_ON = (0-_LEN_ON)
  if (_LEN_ON>0):
    cam.setLed(cam.LED_ON)  # Turn on the fill light of the WonderCam vision module (打开小幻熊视觉模块的补光灯) 
  else:
    cam.setLed(cam.LED_OFF)


def start_main():
  global cam
  global i2csonar_4
  global en_motor
  global _LEN_ON
  global _LAST_CLASS_ID
  global _CLASS_COUNT

  while True:
    cam.updateResult()  # Update and get data from the vision module (更新并获取视觉模块的数据)
    if not ((cam.getLandmarkMaxProbId()==0)):  # If the recognized highest confidence ID is not 0 (0 means no sign detected) （如果识别到的置信度最大编号不为0（为0则表示未识别到任何路标））
      if (_LAST_CLASS_ID==cam.getLandmarkMaxProbId()):  # Check if the saved sign ID matches the currently recognized one (to filter false recognition) （判断保存的路标ID是否与当前识别到的一致（用于过滤误识别））
        _CLASS_COUNT+=1  # Increment the count of sign recognition times （路标识别的次数加1）
      else:  # If not matching, clear the recognition count and restart counting （不一致就清空路标识别次数，重新开始计数）
        _CLASS_COUNT = 0
        _LAST_CLASS_ID = cam.getLandmarkMaxProbId()
      
      # Recognizing the same sign twice means recognition is successful （识别到同一路标两次，则表示识别成功）
      if (_CLASS_COUNT>2):
        if (_LAST_CLASS_ID==2):  # If a left turn sign is recognized, control the car to turn left （识别到了向左转弯路标，控制小车左转）
          en_motor.setSpeed(en_motor.Motor2,53.784)
          en_motor.setSpeed(en_motor.Motor1,-53.784)
          time.sleep(0.5)
          en_motor.stop(en_motor.AllMotor) 
        if (_LAST_CLASS_ID==3):  # If a right turn sign is recognized, control the car to turn right （识别到了向右转弯路标，控制小车右转）
          en_motor.setSpeed(en_motor.Motor1,53.784)
          en_motor.setSpeed(en_motor.Motor2,-53.784)
          time.sleep(0.5)
          en_motor.stop(en_motor.AllMotor)
        if (_LAST_CLASS_ID==1):  # If a forward sign is recognized, control the car to move straight （识别到了前进路标，控制小车直行）
          en_motor.setSpeed(en_motor.AllMotor,30)
          time.sleep(1)
          en_motor.stop(en_motor.AllMotor)
        if (_LAST_CLASS_ID==5):  # If a stop sign is recognized, control the car to stop moving （识别到了停车路标，控制小车停止移动）
          en_motor.stop(en_motor.AllMotor)
        if (_LAST_CLASS_ID==4):  # If a U-turn sign is recognized, control the car to make a left U-turn in place （识别到了掉头路标，控制小车原地向左掉头）
          en_motor.setSpeed(en_motor.Motor1,-53.784)
          en_motor.setSpeed(en_motor.Motor2,53.784)
          time.sleep(1)
          en_motor.stop(en_motor.AllMotor)
        _CLASS_COUNT = 0  # Finally, clear the sign recognition count and restart counting （最后清空路标识别次数，重新开始计数）
    time.sleep(0.05)

Hiwonder.Button_A.Clicked(on_button_A_clicked) # Register button A detection task and set the callback function （注册按键A检测任务，并设置回调函数）
Hiwonder.startMain(start_main)
