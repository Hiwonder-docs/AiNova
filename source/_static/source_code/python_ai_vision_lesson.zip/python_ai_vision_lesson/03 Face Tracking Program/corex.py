import Hiwonder
import time
from Hiwonder import Buzzer

# initialize variables
cam = Hiwonder.WonderCam(Hiwonder.Port(4))  # Initialize the IIC interface of the WonderCam vision module (初始化小幻熊视觉模块的IIC接口)
i2csonar_4 = Hiwonder.I2CSonar(Hiwonder.Port(4))  # Initialize the IIC interface of the RGB ultrasonic sensor (初始化发光超声波的IIC接口) 
en_motor = Hiwonder.EncoderMotor
_LEN_ON = 0
_TRACK_X = 0
_TRACK_Y = 0
area = 0
_SPEED = 0
_DIREC = 0


i2csonar_4.setRGB(0,0x00,0x00,0x00)  # Turn off the RGB light of the ultrasonic sensor (关闭发光超声波的RGB灯)
en_motor.setType(en_motor.TT_MOTOR)  # Initialize the encoder motor model as TT motor (初始化编码电机的型号为TT马达) 
en_motor.stop(en_motor.AllMotor)  # Stop the encoder motor operation (停止编码电机的运行) 
cam.switchFunc(cam.FaceDetect)  # Set the WonderCam vision module to face recognition mode (设置小幻熊视觉模块的工作模式为人脸识别模式）
Buzzer.playTone(698,125,False)
_LEN_ON = -1




def on_button_A_clicked():  # Fill light control function (补光灯控制函数)
  global cam
  global i2csonar_4
  global en_motor
  global _LEN_ON
  global _TRACK_X
  global _TRACK_Y
  global area
  global _SPEED
  global _DIREC

  _LEN_ON = (0-_LEN_ON)  
  if (_LEN_ON>0):
    cam.setLed(cam.LED_ON)  # Turn on the fill light of the WonderCam vision module (打开小幻熊视觉模块的补光灯)
  else:
    cam.setLed(cam.LED_OFF)


def start_main():
  global cam
  global i2csonar_4
  global en_motor
  global _LEN_ON
  global _TRACK_X
  global _TRACK_Y
  global area
  global _SPEED
  global _DIREC

  while True:
    cam.updateResult()  # Update and get data from the vision module (更新并获取视觉模块的数据)
    if cam.isAnyUnlearnedFaceDetected():  # Determine whether an unlearned face is recognized (判断是否识别到未学习的人脸) 
      _TRACK_X = cam.getUnlearnedFaceOfIndex(1)[0]  # Get the X coordinate of the center of the first unlearned face detected (获取识别到的第1个未学习人脸的中心X坐标)
      _TRACK_Y = cam.getUnlearnedFaceOfIndex(1)[1]  # Get the Y coordinate of the center of the first unlearned face detected (获取识别到的第1个未学习人脸的中心Y坐标) 
      area = round((cam.getUnlearnedFaceOfIndex(1)[2]*cam.getUnlearnedFaceOfIndex(1)[3]))  # Calculate the area of the face (计算人脸的面积)  
      print(area)
      if (area<6000):  # If the area is less than 6000 (如果面积小于6000) 
        _SPEED = (((6000-area))*0.012)  # Calculate the motor speed based on the area and move the car forward (根据面积计算电机速度，控制小车前进) 
      else:
        if (area>=7500):  # If the area is greater than or equal to 7500 (若面积大于或等于7500)
          if (area>30000):  # Limit the maximum area to restrict motor speed (限制最大面积，用于限制电机速度) 
            area = 30000
          _SPEED = (0-(((area-7500))*0.002))  # Calculate the motor speed and move the car backward (计算电机速度，控制小车后退) 
      _DIREC = (((160-_TRACK_X))*0.12)  # Calculate whether the car should turn based on the X coordinate of the center (根据中心X的坐标，计算小车是否进行转向) 
      en_motor.setSpeed(en_motor.Motor1,(_SPEED-_DIREC))  # Control the robot movement proportionally (根据比例控制小车进行移动)
      en_motor.setSpeed(en_motor.Motor2,(_SPEED+_DIREC))
    else:  # Stop the motor if no face is recognized (未识别到就停止电机运行)
      en_motor.stop(en_motor.AllMotor)
    time.sleep(0.05)

Hiwonder.Button_A.Clicked(on_button_A_clicked)  # Register button A detection task and set the callback function (注册按键A检测任务，并设置回调函数)
Hiwonder.startMain(start_main)
