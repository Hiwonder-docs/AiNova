import Hiwonder
import time
from Hiwonder import Buzzer

# initialize variables
cam = Hiwonder.WonderCam(Hiwonder.Port(4))  # Initialize the IIC interface of the WonderCam vision module (初始化小幻熊视觉模块的IIC接口)  
i2csonar_4 = Hiwonder.I2CSonar(Hiwonder.Port(4))  # Initialize the IIC interface of the RGB ultrasonic sensor (初始化发光超声波的IIC接口)
en_motor = Hiwonder.EncoderMotor
_LEN_ON = 0


i2csonar_4.setRGB(0,0x00,0x00,0x00)  # Turn off the RGB light of the ultrasonic sensor (关闭发光超声波的RGB灯)
en_motor.setType(en_motor.TT_MOTOR)  # Initialize the encoder motor model as TT motor (初始化编码电机的型号为TT马达)
en_motor.stop(en_motor.AllMotor)  # Stop the encoder motor operation (停止编码电机的运行)
cam.switchFunc(cam.AprilTag)  # Set the WonderCam vision module to tag recognition mode (设置小幻熊视觉模块的工作模式为标签识别模式）
Buzzer.playTone(698,125,False)
_LEN_ON = -1




def on_button_A_clicked():  # Fill light control function (补光灯控制函数)
  global cam
  global i2csonar_4
  global en_motor
  global _LEN_ON

  _LEN_ON = (0-_LEN_ON)
  if (_LEN_ON>0):
    cam.setLed(cam.LED_ON)  # Turn on the fill light of the WonderCam vision module (打开小幻熊视觉模块的补光灯) 
  else:
    cam.setLed(cam.LED_OFF)


def start_main():
  global cam
  global i2csonar_4
  global en_motor
  global _LEN_ON

  while True:
    cam.updateResult()  # Update and get data from the vision module (更新并获取视觉模块的数据)
    if cam.isTagOfIdDetected(1):  # If tag 1 is recognized (如果识别到标签1)  
      Hiwonder.Neopixel_onboard.fill(0xff,0x00,0x00)  # Turn on red RGB light (RGB彩灯亮红灯)  
      Buzzer.playTone(2637,125,False)  # Make the buzzer beep once (蜂鸣器鸣响一声)  
      time.sleep(1)
    else:
      if cam.isTagOfIdDetected(2):  # If tag 2 is recognized (识别到标签2)  
        Hiwonder.Neopixel_onboard.fill(0x00,0xcc,0x00)  # Turn on green RGB light (RGB彩灯亮绿灯)  
        Buzzer.playTone(2637,125,False)  # Make the buzzer beep twice (蜂鸣器鸣响两声) 
        time.sleep(0.2)
        Buzzer.playTone(2637,125,False)
        time.sleep(1)
      else:
        if cam.isTagOfIdDetected(3):  # If tag 3 is recognized (识别到标签3)
          Hiwonder.Neopixel_onboard.fill(0x00,0x00,0x99)  # Turn on blue RGB light (RGB彩灯亮蓝灯)  
          Buzzer.playTone(2637,125,False)  # Make the buzzer beep three times (蜂鸣器鸣响三声)  
          time.sleep(0.2)
          Buzzer.playTone(2637,125,False)
          time.sleep(0.2)
          Buzzer.playTone(2637,125,False)
          time.sleep(1)
        else:
          Hiwonder.Neopixel_onboard.clear()  # If no tag is recognized, turn off the RGB light (没有识别到标签则关闭RGB灯)
          time.sleep(0.01)
    time.sleep(0.05)

Hiwonder.Button_A.Clicked(on_button_A_clicked)  # Register button A detection task and set the callback function (注册按键A检测任务，并设置回调函数)
Hiwonder.startMain(start_main)
