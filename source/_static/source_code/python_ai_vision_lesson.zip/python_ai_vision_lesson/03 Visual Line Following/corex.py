import Hiwonder
import time
from Hiwonder import Buzzer

# initialize variables
cam = Hiwonder.WonderCam(Hiwonder.Port(4))  # Initialize the IIC interface of the WonderCam vision module (初始化小幻熊视觉模块的IIC接口) 
i2csonar_4 = Hiwonder.I2CSonar(Hiwonder.Port(4))  # Initialize the IIC interface of the RGB ultrasonic sensor (初始化发光超声波的IIC接口)
_LEN_ON = 0
_ANGLE = 0
_OFFSET = 0
_SPEED = 0
_ERR = 0
_I = 0
_DIREC = 0
_ERR_LAST = 0


i2csonar_4.setRGB(0,0x00,0x00,0x00)  # Turn off the RGB light of the ultrasonic sensor (关闭发光超声波的RGB灯) 
en_motor.setType(en_motor.TT_MOTOR)  # Initialize the encoder motor model as TT motor (初始化编码电机的型号为TT马达) 
en_motor.stop(en_motor.AllMotor) 
cam.switchFunc(cam.LineFollowing)  # Set the WonderCam vision module to line tracking mode （设置小幻熊视觉模块的工作模式为视觉巡线模式）
cam.setLed(cam.LED_ON)  # Turn on the WonderCam vision module’s fill light （打开小幻熊视觉模块的补光灯）
Buzzer.playTone(698,125,False)
_LEN_ON = -1

def on_button_A_clicked():  # Fill light control function （补光灯控制函数）
  global cam
  global i2csonar_4
  global en_motor
  global _LEN_ON
  global _ANGLE
  global _OFFSET
  global _SPEED
  global _ERR
  global _I
  global _DIREC
  global _ERR_LAST

  _LEN_ON = (0-_LEN_ON)
  if (_LEN_ON>0):
    cam.setLed(cam.LED_ON)
  else:
    cam.setLed(cam.LED_OFF)

def start_main():
  global cam
  global i2csonar_4
  global en_motor
  global _LEN_ON
  global _ANGLE
  global _OFFSET
  global _SPEED
  global _ERR
  global _I
  global _DIREC
  global _ERR_LAST

  '''
    #Set the region for visual line tracking (设置视觉巡线的区域)
    Parameter 1: X-axis coordinate of the top-left corner(参数1: 左上角的X轴坐标)
    Parameter 2: Y-axis coordinate of the top-left corner(参数2: 左上角的Y轴坐标)
    Parameter 3: Region width W(参数3: 区域宽度W)
    Parameter 4: Region height H(参数4: 区域高度H)
  '''
  cam.setRoi(0,180,319,59)
  
  while True:
    cam.updateResult()  # Update and obtain data from the vision module （更新并获取视觉模块的数据）
    if cam.isAnyLineDetected():  # Determine whether a route has been detected （判断是否检测到了路线） 
      if cam.isLineOfIdDetected(1):  #If route ID 1 is recognized （如果识别到了ID为1的路线）  
        _ANGLE = cam.getLineOfId(1)[4]  # Get the angle and offset of route 1 （获取线路1的角度以及偏移量）  
        _OFFSET = cam.getLineOfId(1)[5]
        Hiwonder.Neopixel_onboard.fill(128,0,0)  # Set the RGB light to red （设置RGB灯为红色）
        _SPEED = 45
      else:
        if cam.isLineOfIdDetected(2):  # If route ID 2 is recognized （如果识别到了ID为2的路线） 
          _ANGLE = cam.getLineOfId(2)[4]  # Get the angle and offset of route 2 （获取线路2的角度以及偏移量）
          _OFFSET = cam.getLineOfId(2)[5]
          Hiwonder.Neopixel_onboard.fill(0,128,0)  # Set the RGB light to green （设置RGB灯为绿色）
          _SPEED = 45
        else:
          if cam.isLineOfIdDetected(3):  # If route ID 3 is recognized （如果识别到了ID为3的路线） 
            _ANGLE = cam.getLineOfId(3)[4]  # Get the angle and offset of route 3 （获取线路3的角度以及偏移量）
            _OFFSET = cam.getLineOfId(3)[5]
            Hiwonder.Neopixel_onboard.fill(0,0,128)  # Set the RGB light to blue （设置RGB灯为蓝色）
            _SPEED = 45
          else:  # If no specified route is recognized, clear the data （未识别到指定线路则清空数据）
            _SPEED = 0
            _ANGLE = 0
            _OFFSET = 0
      
      
      _ERR = (0-_OFFSET)
      _I = (_ERR+_I)
      if (_I>100):
        _I = 100
      if (_I<-100):
        _I = -100
      _DIREC = ((((_ERR*0.07)+(_I*0.05)))+(((_ERR-_ERR_LAST))*0.15)) # Calculate motor offset using PID algorithm （通过PID算法计算出电机的偏移量）

      en_motor.setSpeed(en_motor.Motor1,(_SPEED-_DIREC)) # Control motor rotation based on the calculated result （根据计算结果控制电机转动）
      en_motor.setSpeed(en_motor.Motor2,(_SPEED+_DIREC))
      _ERR_LAST = _ERR
    else:  # If no route is recognized （未识别到任何线路）
      en_motor.stop(en_motor.AllMotor)  # Stop motor rotation （停止电机转动）
      Hiwonder.Neopixel_onboard.clear()  # Turn off the RGB light （关闭RGB灯） 
      time.sleep(0.01)
      _ERR = 0
      _I = 0
      _ERR_LAST = 0

Hiwonder.startMain(start_main)  # Register button A detection task and set callback function （注册按键A检测任务，并设置回调函数）
Hiwonder.Button_A.Clicked(on_button_A_clicked)
