#include "robotrun.h"

void robotrun::begin(void)
{
  ets_serial.begin(115200);
}

void robotrun::set_motor_speed(int m1, int m2)
{
    uint8_t buf[6] = {0x55, 0x55, 0x04, 0x32, 0x00, 0x00};
    m1 = m1 > 100 ? 100 : m1;
    m2 = m2 > 100 ? 100 : m2;
    m1 = m1 < -100 ? -100 : m1;
    m2 = m2 < -100 ? -100 : m2;
    m1 = -m1;
    m2 = -m2;
    buf[4] = m2 & 0xFF;
    buf[5] = m1 & 0xFF;
    ets_serial.write(buf,6);
}

void robotrun::hw_encoder_motor_set_motor_type(uint8_t motortype)
{
    if (motortype == 1 || motortype == 2) {
        uint8_t buf[] = {0x55, 0x55, 0x04, 55, 1, 0};
        buf[5] = motortype;
        ets_serial.write(buf,6);
    }
}


int robotrun::hw_encoder_motor_set_speed_base(float new_speed1, float new_speed2)
{
    uint8_t buf[] = {0x55, 0x55, 0x05, 55, 0x02, 0x00, 0x00};
    float rps1 = (float)(-new_speed1) / 60.0f;
    float rps2 = (float)(-new_speed2) / 60.0f;
    float pps1 = rps1 * 680;
    float pps2 = rps2 * 680;
    buf[5] = (uint8_t)((int)round(pps1 * 0.01f));
    buf[6] = (uint8_t)((int)round(pps2 * 0.01f));
    ets_serial.write(buf,7);
    return 0;
}

