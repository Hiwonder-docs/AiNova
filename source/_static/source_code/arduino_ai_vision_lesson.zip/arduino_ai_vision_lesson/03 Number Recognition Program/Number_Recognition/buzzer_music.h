#ifndef BUZZER_MUSIC_H_
#define BUZZER_MUSIC_H_

#include <Arduino.h>

class buzzer_music
{
  private:
    uint8_t pin;

  public:
    buzzer_music(uint8_t pin);
    void playTone(uint16_t freq, uint16_t duration);

    void xiao_mao_lv(void);
    void liang_zhi_lao_hu(void);
    void xiao_xing_xing(void);

};

#endif //BUZZER_MUSIC_H_

