#include "buzzer_music.h"

buzzer_music::buzzer_music(uint8_t pin)
{
  this->pin = pin;
}

void buzzer_music::playTone(uint16_t freq, uint16_t duration) 
{
  tone(this->pin, freq, duration);
  delay(duration);
}

// Little Donkey（小毛驴）
void buzzer_music::xiao_mao_lv(void)
{
  playTone(523,500);
  playTone(523,500);
  playTone(523,500);
  playTone(659,500);
  playTone(784,500);
  playTone(784,500);
  playTone(784,500);
  playTone(784,500);
  playTone(880,500);
  playTone(880,500);
  playTone(880,500);
  playTone(1047,500);
  playTone(784,1000);
  playTone(698,500);
  playTone(698,500);
  playTone(698,500);
  playTone(880,500);
  playTone(659,500);
  playTone(659,500);
  playTone(659,500);
  playTone(659,500);
  playTone(587,500);
  playTone(587,500);
  playTone(587,500);
  playTone(587,500);
  playTone(784,750);
  playTone(523,500);
  playTone(523,500);
  playTone(523,500);
  playTone(659,500);
  playTone(784,500);
  playTone(784,500);
  playTone(784,500);
  playTone(784,500);
  playTone(880,500);
  playTone(880,500);
  playTone(880,500);
  playTone(1047,500);
  playTone(784,1000);
  playTone(698,500);
  playTone(698,500);
  playTone(698,500);
  playTone(880,500);
  playTone(659,250);
  playTone(659,250);
  playTone(659,250);
  playTone(659,250);
  playTone(659,500);
  playTone(659,500);
  playTone(587,500);
  playTone(587,500);
  playTone(587,500);
  playTone(659,500);
  playTone(523,1000);
}

// Two Tigers（两只老虎）
void buzzer_music::liang_zhi_lao_hu(void)
{
  int i = 0;
  for(i = 0; i<2 ; i++)
  {
    playTone(523,500);
    playTone(587,500);
    playTone(659,500);
    playTone(523,500);
  }
  for(i = 0; i<2 ; i++)
  {
    playTone(659,500);
    playTone(698,500);
    playTone(784,1000);
  }
  for(i = 0; i<2 ; i++)
  {
    playTone(784,250);
    playTone(880,250);
    playTone(784,250);
    playTone(698,250);
    playTone(659,500);
    playTone(523,500);
  }
  for(i = 0; i<2 ; i++)
  {
    playTone(523,500);
    playTone(392,500);
    playTone(523,1000);
  }
}

// Twinkle Twinkle Little Star（小星星）
void buzzer_music::xiao_xing_xing(void)
{
  playTone(523,500);
  playTone(523,500);
  playTone(784,500);
  playTone(784,500);
  playTone(880,500);
  playTone(880,500);
  playTone(784,1000);
  playTone(698,500);
  playTone(698,500);
  playTone(659,500);
  playTone(659,500);
  playTone(587,500);
  playTone(587,500);
  playTone(523,1000);

  for(int i = 0 ; i < 2 ; i++)
  {
    playTone(784,500);
    playTone(784,500);
    playTone(698,500);
    playTone(698,500);
    playTone(659,500);
    playTone(659,500);
    playTone(587,1000);
  }

  playTone(523,500);
  playTone(523,500);
  playTone(784,500);
  playTone(784,500);
  playTone(880,500);
  playTone(880,500);
  playTone(784,1000);
  playTone(698,500);
  playTone(698,500);
  playTone(659,500);
  playTone(659,500);
  playTone(587,500);
  playTone(587,500);
  playTone(523,1000);
}
