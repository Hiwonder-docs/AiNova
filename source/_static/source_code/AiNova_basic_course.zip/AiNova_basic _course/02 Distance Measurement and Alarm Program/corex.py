import Hiwonder
import time
from Hiwonder import Buzzer

# initialize variables
en_motor = Hiwonder.EncoderMotor
i2csonar_4 = Hiwonder.I2CSonar(Hiwonder.Port(4))  # Initialize the IIC interface of the RGB ultrasonic module (初始化发光超声波的IIC接口) 
distance = 0


en_motor.setType(en_motor.TT_MOTOR)  # Initialize the encoder motor type as TT motor (初始化编码电机的型号为TT马达)
i2csonar_4.startSymphony()  # Set the RGB light mode of the ultrasonic module to rainbow mode (设置发光超声波的RGB彩灯模式为幻彩模式)



def start_main():
  global en_motor
  global i2csonar_4
  global distance

  while True:
    distance = i2csonar_4.getDistance()  # Get the distance from the ultrasonic module (获取发光超声波的距离)
    if ((distance>0) and (distance<50)):  # If the distance is greater than 0cm and less than 50cm (如果距离大于0cm且小于50cm) 
      if (distance>10):  # When the distance is greater than 10cm (当距离大于10cm时) 
        Buzzer.playTone(1319,125,False)
        Hiwonder.Neopixel_onboard.fill(100,round((((distance*2)-20))),round((((distance*2)-20))))  # Set the onboard RGB light color based on the distance (根据距离设置板载RGB灯颜色) 
        i2csonar_4.setRGB(0,100,round((((distance*2)-20))),round((((distance*2)-20))))  # Set the RGB light color of the ultrasonic module based on the distance (根据距离设置发光超声波的RGB灯颜色)
        time.sleep((0.01*distance))
      else:
        Buzzer.playTone(1319,1000,False)  # If the distance is less than 10cm (若距离小于10cm)
        Hiwonder.Neopixel_onboard.fill(100,0,0)  # Set the onboard RGB light to red (设置板载RGB灯为红色)  
        time.sleep(1)
    else:  # If the distance is greater than or equal to 50cm (距离大于或等于50时)
      Hiwonder.Neopixel_onboard.fill(100,100,100)  # Set the onboard RGB light color to white (设置板载RGB的颜色为白色)
      i2csonar_4.startSymphony()  # Set the RGB light mode of the ultrasonic module to rainbow mode again (设置发光超声波的RGB彩灯模式为幻彩模式)
      time.sleep(0.1)

Hiwonder.startMain(start_main)

