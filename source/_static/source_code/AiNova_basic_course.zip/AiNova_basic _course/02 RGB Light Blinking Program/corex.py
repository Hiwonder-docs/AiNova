import time
import random
import Hiwonder

# initialize variables
count = 0
R = 0
B = 0
G = 0
R_Gradient = 0
G_Gradient = 0
B_Gradient = 0

def flash_onebyone():   #Flash one by one(逐一闪烁)
  global count

  count = 1
  while not (count>6):
    Hiwonder.Neopixel_onboard.setItem(count-1,50,206,250)  #Set RGB light color(设置RGB灯的颜色)
    Hiwonder.Neopixel_onboard.write()
    count+=1
    time.sleep(0.1)
    Hiwonder.Neopixel_onboard.clear()
    time.sleep(0.01)

def light_onebyone():   #Light one by one(逐一亮起)
  global count

  Hiwonder.Neopixel_onboard.clear()
  time.sleep(0.01)
  count = 1
  time.sleep(0.3)
  while not (count>6):
    Hiwonder.Neopixel_onboard.setItem(count-1,50,206,250)
    Hiwonder.Neopixel_onboard.write()
    count+=1
    time.sleep(0.3)

def random_color():   #Random color(随机颜色)
  global R
  global B
  global G

  R = random.randint(1,255)
  B = random.randint(1,255)
  G = random.randint(1,255)
  Hiwonder.Neopixel_onboard.setItem(round(random.randint(1,6))-1,round(R),round(G),round(B))
  Hiwonder.Neopixel_onboard.write()

def flash_all():   # Flash all(全部闪烁)
  Hiwonder.Neopixel_onboard.fill(50,206,250)
  time.sleep(0.3)
  Hiwonder.Neopixel_onboard.clear()
  time.sleep(0.01)

def light_breath():   # Light breath(呼吸渐变)
  global count
  global R
  global B
  global G
  global R_Gradient
  global G_Gradient
  global B_Gradient

  R = random.randint(5,250)
  B = random.randint(5,250)
  G = random.randint(5,250)
  R_Gradient = 3
  G_Gradient = 5
  B_Gradient = 7
  while True:
    if ((R>245) or (R<10)):
      R_Gradient = (0-R_Gradient)
    if ((G>245) or (G<10)):
      G_Gradient = (0-G_Gradient)
    if ((B>245) or (B<10)):
      B_Gradient = (0-B_Gradient)
    R+=R_Gradient
    G+=G_Gradient
    B+=B_Gradient
    Hiwonder.Neopixel_onboard.fill(round(R),round(G),round(B))
    time.sleep(0.01)


def start_main():
  global count

  for count in range(3):
    flash_onebyone()
  light_onebyone()
  Hiwonder.Neopixel_onboard.clear()
  time.sleep(0.01)
  for count in range(5):
    flash_all()
    time.sleep(0.3)
  for count in range(50):
    random_color()
    time.sleep(0.1)
  light_breath()

Hiwonder.startMain(start_main)


