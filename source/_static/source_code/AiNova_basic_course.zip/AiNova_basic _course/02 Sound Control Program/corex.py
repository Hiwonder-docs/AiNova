import Hiwonder
import time
from Hiwonder import Buzzer

# initialize variables
en_motor = Hiwonder.EncoderMotor
i2csonar_4 = Hiwonder.I2CSonar(Hiwonder.Port(4))  # Initialize the IIC interface of the RGB ultrasonic module to port 4 (初始化发光超声波的IIC接口为4号)  
sound_count = 0
count = 0


en_motor.setType(en_motor.TT_MOTOR)  # Initialize the encoder motor type as TT motor (初始化编码电机的型号为TT马达)
i2csonar_4.startSymphony()  # Set the RGB light mode of the ultrasonic module to color-changing mode (设置发光超声波的RGB彩灯模式为幻彩模式)
Buzzer.playTone(1319,125,False)  # Make the buzzer beep once (控制蜂鸣器鸣响一声)  
time.sleep(0.5)




def start_main():
  global en_motor
  global i2csonar_4
  global sound_count
  global count

  while True:
    sound_count = 0
    if (Hiwonder.Sound_onboard.read()>80):  # If the detected sound is greater than 80 (如果检测到的声音大于80)
      sound_count = 1
      count = 500
      time.sleep(0.07)
      while not (count<=0):  # Continuously check for a second sound (循环检测是否有第二次声音)
        count+=-1
        if (Hiwonder.Sound_onboard.read()>80): 
          sound_count = 2
    if (sound_count==1):  # When the sound count is 1, control the car to go straight (当声音次数为1时，控制小车直行)
      Buzzer.playTone(1397,125,False)
      en_motor.setSpeed(en_motor.AllMotor,50)
      time.sleep(2)
      en_motor.stop(en_motor.AllMotor)
      time.sleep(0.5)
    else:
      if (sound_count==2):  # When the sound count is 2, control the car to turn in place (当声音次数为2时，控制小车进行原地转弯)
        Buzzer.playTone(1397,125,False)
        time.sleep(0.2)
        Buzzer.playTone(1397,125,False)
        en_motor.setSpeed(en_motor.Motor1,50)
        en_motor.setSpeed(en_motor.Motor2,-50)
        time.sleep(0.94)
        en_motor.stop(en_motor.AllMotor)
        time.sleep(0.5)
      else:
        pass

Hiwonder.startMain(start_main)

