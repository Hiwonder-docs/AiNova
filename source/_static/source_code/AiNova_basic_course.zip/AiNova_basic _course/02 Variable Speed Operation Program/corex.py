import Hiwonder
import time

# initialize variables
en_motor = Hiwonder.EncoderMotor
i2csonar_4 = Hiwonder.I2CSonar(Hiwonder.Port(4))  # Initialize the IIC interface of the RGB ultrasonic module to port 4 (初始化发光超声波的IIC接口为4号) 
speed_change = 0  # Speed delta (速度变化量) 
speed = 0  # Actual speed (实际速度)


en_motor.setType(en_motor.TT_MOTOR)  # Initialize the encoder motor type as TT motor (初始化编码电机的型号为TT马达)
i2csonar_4.startSymphony()  # Set the RGB light mode of the ultrasonic module to color-changing mode (设置发光超声波的RGB彩灯模式为幻彩模式)




def start_main():
  global en_motor
  global i2csonar_4
  global speed_change
  global speed

  speed_change = 3 
  speed = 50
  while True:
    if ((speed<=20) or (speed>120)):  # Limit the speed within the range of 20 to 120 (将速度限制在20-120之间) 
      speed_change = (0-speed_change)
    speed+=speed_change
    en_motor.setSpeed(en_motor.AllMotor,speed)  # Control the speed of two motors (控制两个电机的速度)
    time.sleep(0.01)

Hiwonder.startMain(start_main)


