import Hiwonder
import time

# initialize variables
en_motor = Hiwonder.EncoderMotor
i2csonar_4 = Hiwonder.I2CSonar(Hiwonder.Port(4))  # Initialize the IIC interface of the RGB ultrasonic sensor (初始化发光超声波的IIC接口)  
distance = 0


en_motor.setType(en_motor.TT_MOTOR)  # Initialize the encoder motor type as TT motor (初始化编码电机的型号为TT马达) 
i2csonar_4.startSymphony()  # Set the RGB light mode of the ultrasonic sensor to rainbow mode (设置发光超声波的RGB彩灯模式为幻彩模式) 


def start_main():
  global en_motor
  global i2csonar_4
  global distance

  while True:
    distance = i2csonar_4.getDistance()  # Get the distance from the RGB ultrasonic sensor (获取发光超声波的距离) 
    if ((distance>0) and (distance<20)):  # If the distance is greater than 0 and less than 20 (如果距离大于0且小于20)
      en_motor.setSpeed(en_motor.Motor1,50)  # Control the car to turn right (控制小车进行右转) 
      en_motor.setSpeed(en_motor.Motor2,-50)
      time.sleep(0.47)
      en_motor.stop(en_motor.AllMotor)
      time.sleep(0.1)
    else:
      en_motor.setSpeed(en_motor.AllMotor,50)  # Control the car to go straight (控制小车直行)

Hiwonder.startMain(start_main)
