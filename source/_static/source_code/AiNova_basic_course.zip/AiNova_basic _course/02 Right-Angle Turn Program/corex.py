import Hiwonder
import time

# initialize variables
en_motor = Hiwonder.EncoderMotor
i2csonar_4 = Hiwonder.I2CSonar(Hiwonder.Port(4))  # Initialize the IIC interface of the RGB ultrasonic module to port 4 (初始化发光超声波的IIC接口为4号)  


en_motor.setType(en_motor.TT_MOTOR)  # Initialize the encoder motor type as TT motor (初始化编码电机的型号为TT马达)  
i2csonar_4.startSymphony()  # Set the RGB light mode of the ultrasonic module to color-changing mode (设置发光超声波的RGB彩灯模式为幻彩模式)


def start_main():
  global en_motor
  global i2csonar_4

  while True:
    en_motor.setSpeed(en_motor.AllMotor,50)  # Set the speed of all motors to 50 RPM (设置全部电机的速度为50转/分钟)
    time.sleep(3)
    en_motor.stop(en_motor.AllMotor)  # Stop all motor rotation (停止全部电机转动) 
    time.sleep(0.1)
    en_motor.setSpeed(en_motor.Motor1,50)  # Set the speed of motor 1 to 50 (设置1号电机的速度为50)
    en_motor.setSpeed(en_motor.Motor2,-50)  # Set the speed of motor 2 to -50 (设置2号电机的速度为-50) 
    time.sleep(0.45)
    en_motor.stop(en_motor.AllMotor)  # Stop rotation (停止转动)
    time.sleep(0.1)

Hiwonder.startMain(start_main)

