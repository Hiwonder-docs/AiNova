import Hiwonder
import time

en_motor = Hiwonder.EncoderMotor
i2csonar_4 = Hiwonder.I2CSonar(Hiwonder.Port(4))  # Initialize the IIC interface of the RGB ultrasonic module to port 4 (初始化发光超声波的IIC接口为4号)  

en_motor.setType(en_motor.TT_MOTOR)  # Initialize the encoder motor type as TT motor (初始化编码电机的型号为TT马达) 
i2csonar_4.startSymphony()  # Set the RGB light mode of the ultrasonic module to color-changing mode (设置发光超声波的RGB彩灯模式为幻彩模式) 


def start_main():
  global en_motor
  global i2csonar_4

  en_motor.setSpeed(en_motor.AllMotor,50)  #  Control all motors to move forward at a speed of 50 RPM (控制全部电机以50转/分钟的速度向前移动)

Hiwonder.startMain(start_main)



