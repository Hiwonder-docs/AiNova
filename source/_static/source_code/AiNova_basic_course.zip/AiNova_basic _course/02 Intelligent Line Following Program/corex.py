import Hiwonder
import time
from Hiwonder import Buzzer

# initialize variables
i2csonar_5 = Hiwonder.I2CSonar(Hiwonder.Port(4))  # Initialize the IIC interface of the 4-way line tracking sensor (初始化四路巡线传感器的IIC接口)
en_motor = Hiwonder.EncoderMotor
i2csonar_4 = Hiwonder.I2CSonar(Hiwonder.Port(4))  # Initialize the IIC interface of the RGB ultrasonic module (初始化发光超声波的IIC接口) 

_Sensor1 = 0
_Sensor2 = 0
_Sensor3 = 0
_Sensor4 = 0


i2csonar_5.setRGB(0,0x00,0x00,0x00)  # Turn off the RGB light of the ultrasonic module (关闭发光超声波的RGB灯) 
en_motor.setType(en_motor.TT_MOTOR)  # Initialize the encoder motor type as TT motor (初始化编码电机的型号为TT马达)
Buzzer.playTone(698,125,False)  # Make the buzzer beep once (蜂鸣器鸣响一声)  




def start_main():
  global i2csonar_5
  global en_motor
  global _Sensor1
  global lineSensor_4
  global _Sensor2
  global _Sensor3
  global _Sensor4

  while True:
    _Sensor1 = (lineSensor_4.read(lineSensor_4.Sensor1))  # Get data from the 4-way line tracking sensor (获取四路巡线传感器数据) 
    _Sensor2 = (lineSensor_4.read(lineSensor_4.Sensor2))
    _Sensor3 = (lineSensor_4.read(lineSensor_4.Sensor3))
    _Sensor4 = (lineSensor_4.read(lineSensor_4.Sensor4))
    if (((not _Sensor1 and _Sensor2)) and ((_Sensor3 and not _Sensor4))):  # If the line is detected in the middle (如果识别到线路在中间)
      en_motor.setSpeed(en_motor.AllMotor,40)  # Control the car to go straight (控制小车直行)
    else:
      if (((not _Sensor1 and _Sensor2)) and ((not _Sensor3 and not _Sensor4))):
        en_motor.setSpeed(en_motor.Motor1,6)  # Control the car to turn left (控制小车左转)
        en_motor.setSpeed(en_motor.Motor2,40)
      else:
        if (((not _Sensor1 and not _Sensor2)) and ((_Sensor3 and not _Sensor4))):
          en_motor.setSpeed(en_motor.Motor1,40)  # Control the car to turn right (控制小车右转)
          en_motor.setSpeed(en_motor.Motor2,6)
        else:
          pass

Hiwonder.startMain(start_main)
